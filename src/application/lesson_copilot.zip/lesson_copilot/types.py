from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Mapping


@dataclass(frozen=True, slots=True)
class CopilotContext:
    course_id: str
    lesson_id: str
    session_id: str | None = None
    subject: str | None = None
    user_id: str | None = None


@dataclass(frozen=True, slots=True)
class CopilotToolSchema:
    name: str
    description: str
    input_schema: Mapping[str, Any]


@dataclass(frozen=True, slots=True)
class CopilotTool:
    schema: CopilotToolSchema
    handler: Callable[[CopilotContext, Mapping[str, Any]], Any]


@dataclass(frozen=True, slots=True)
class AgentToolCall:
    name: str
    arguments: Mapping[str, Any] = field(default_factory=dict)
    reasoning: str | None = None


@dataclass(frozen=True, slots=True)
class AgentToolResult:
    name: str
    ok: bool
    content: Any = None
    error: str | None = None


@dataclass(frozen=True, slots=True)
class CopilotRunStep:
    index: int
    thought: str | None = None
    tool_call: AgentToolCall | None = None
    tool_result: AgentToolResult | None = None
    final_answer: str | None = None


@dataclass(frozen=True, slots=True)
class CopilotRunResult:
    answer: str
    steps: tuple[CopilotRunStep, ...] = ()
    metadata: Mapping[str, Any] = field(default_factory=dict)
