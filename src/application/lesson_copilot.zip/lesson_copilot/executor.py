from __future__ import annotations

from typing import Any

from .tool_registry import LessonCopilotToolRegistry
from .types import AgentToolCall, AgentToolResult, CopilotContext


class LessonCopilotExecutor:
    def __init__(self, *, registry: LessonCopilotToolRegistry) -> None:
        self.registry = registry

    def execute(self, context: CopilotContext, call: AgentToolCall) -> AgentToolResult:
        tool = self.registry.get(call.name)
        try:
            content = tool.handler(context, dict(call.arguments))
        except Exception as exc:
            return AgentToolResult(name=call.name, ok=False, error=str(exc))
        return AgentToolResult(name=call.name, ok=True, content=content)
