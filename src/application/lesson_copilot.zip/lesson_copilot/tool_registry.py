from __future__ import annotations

from dataclasses import asdict, is_dataclass
from typing import Any, Callable, Mapping, Sequence

from .tool_schemas import (
    GENERATE_LESSON_NOTE_TOOL,
    GENERATE_LESSON_QUIZ_TOOL,
    GET_LESSON_ASSETS_TOOL,
    GET_LESSON_NOTE_TOOL,
    GET_LESSON_TRANSCRIPTS_TOOL,
    GET_LESSON_VIDEOS_TOOL,
    QUERY_LESSON_KNOWLEDGE_TOOL,
)
from .types import CopilotContext, CopilotTool


class LessonCopilotToolRegistry:
    def __init__(self, tools: Sequence[CopilotTool] = ()) -> None:
        self._tools = {tool.schema.name: tool for tool in tools}

    def register(self, tool: CopilotTool) -> None:
        self._tools[tool.schema.name] = tool

    def get(self, name: str) -> CopilotTool:
        try:
            return self._tools[name]
        except KeyError as exc:
            raise KeyError(f"unknown tool: {name}") from exc

    def list_tools(self) -> tuple[CopilotTool, ...]:
        return tuple(self._tools.values())


def build_default_lesson_copilot_tools(
    *,
    get_lesson_note: Callable[[str, str], Any] | None = None,
    generate_lesson_note: Callable[..., Any] | None = None,
    get_lesson_transcripts: Callable[[str, str], Sequence[Mapping[str, Any]]] | None = None,
    get_lesson_videos: Callable[[str, str], Sequence[Any]] | None = None,
    get_lesson_assets: Callable[[str, str], Sequence[Any]] | None = None,
    generate_lesson_quiz: Callable[..., Any] | None = None,
    query_lesson_knowledge: Callable[..., Any] | None = None,
) -> LessonCopilotToolRegistry:
    registry = LessonCopilotToolRegistry()

    if get_lesson_note is not None:
        registry.register(
            CopilotTool(
                schema=GET_LESSON_NOTE_TOOL,
                handler=lambda context, arguments: _serialize(
                    get_lesson_note(context.course_id, context.lesson_id)
                ),
            )
        )

    if generate_lesson_note is not None:
        registry.register(
            CopilotTool(
                schema=GENERATE_LESSON_NOTE_TOOL,
                handler=lambda context, arguments: _serialize(
                    generate_lesson_note(
                        course_id=context.course_id,
                        lesson_id=context.lesson_id,
                        session_id=context.session_id,
                        focus=_optional_text(arguments.get("focus")),
                        max_items=_optional_int(arguments.get("max_items")),
                        force=bool(arguments.get("force", False)),
                    )
                ),
            )
        )

    if get_lesson_transcripts is not None:
        registry.register(
            CopilotTool(
                schema=GET_LESSON_TRANSCRIPTS_TOOL,
                handler=lambda context, arguments: _filter_transcripts(
                    get_lesson_transcripts(context.course_id, context.lesson_id),
                    limit=_optional_int(arguments.get("limit")) or 6,
                    source_type=_optional_text(arguments.get("source_type")),
                ),
            )
        )

    if get_lesson_videos is not None:
        registry.register(
            CopilotTool(
                schema=GET_LESSON_VIDEOS_TOOL,
                handler=lambda context, arguments: [_serialize(item) for item in get_lesson_videos(context.course_id, context.lesson_id)],
            )
        )

    if get_lesson_assets is not None:
        registry.register(
            CopilotTool(
                schema=GET_LESSON_ASSETS_TOOL,
                handler=lambda context, arguments: [_serialize(item) for item in get_lesson_assets(context.course_id, context.lesson_id)],
            )
        )

    if generate_lesson_quiz is not None:
        registry.register(
            CopilotTool(
                schema=GENERATE_LESSON_QUIZ_TOOL,
                handler=lambda context, arguments: _serialize(
                    generate_lesson_quiz(
                        session_id=context.session_id,
                        focus=_optional_text(arguments.get("focus")),
                        question_count=_optional_int(arguments.get("question_count")),
                        course_id=context.course_id,
                        lesson_id=context.lesson_id,
                    )
                ),
            )
        )

    if query_lesson_knowledge is not None:
        registry.register(
            CopilotTool(
                schema=QUERY_LESSON_KNOWLEDGE_TOOL,
                handler=lambda context, arguments: _serialize(
                    query_lesson_knowledge(
                        session_id=context.session_id,
                        course_id=context.course_id,
                        lesson_id=context.lesson_id,
                        question=_required_text(arguments.get("question"), "question"),
                        top_k=_optional_int(arguments.get("top_k")) or 5,
                    )
                ),
            )
        )

    return registry


def _filter_transcripts(
    items: Sequence[Mapping[str, Any]],
    *,
    limit: int,
    source_type: str | None,
) -> list[dict[str, Any]]:
    filtered: list[dict[str, Any]] = []
    normalized_source = (source_type or "").strip().lower()
    for item in items:
        if normalized_source and str(item.get("source_type") or "").lower() != normalized_source:
            continue
        filtered.append(
            {
                "session_id": item.get("session_id"),
                "chunk_id": item.get("chunk_id"),
                "source_type": item.get("source_type"),
                "text": item.get("clean_text") or item.get("text"),
                "created_at": item.get("created_at"),
                "metadata": item.get("metadata") or {},
            }
        )
        if len(filtered) >= max(1, limit):
            break
    return filtered


def _serialize(value: Any) -> Any:
    if value is None:
        return None
    if is_dataclass(value):
        return asdict(value)
    if isinstance(value, Mapping):
        return dict(value)
    if isinstance(value, (list, tuple)):
        return [_serialize(item) for item in value]
    return value


def _optional_text(value: Any) -> str | None:
    if value is None:
        return None
    text = " ".join(str(value).strip().split())
    return text or None


def _optional_int(value: Any) -> int | None:
    if value is None:
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def _required_text(value: Any, field_name: str) -> str:
    text = _optional_text(value)
    if not text:
        raise ValueError(f"{field_name} is required")
    return text
