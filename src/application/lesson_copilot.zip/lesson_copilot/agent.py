from __future__ import annotations

import json
from typing import Any, Mapping

from .executor import LessonCopilotExecutor
from .prompts import build_decision_prompt, build_final_answer_prompt
from .tool_registry import LessonCopilotToolRegistry
from .types import (
    AgentToolCall,
    AgentToolResult,
    CopilotContext,
    CopilotRunResult,
    CopilotRunStep,
)


class LessonCopilotAgent:
    def __init__(
        self,
        *,
        llm: Any,
        registry: LessonCopilotToolRegistry,
        max_steps: int = 6,
    ) -> None:
        self.llm = llm
        self.registry = registry
        self.executor = LessonCopilotExecutor(registry=registry)
        self.max_steps = max(1, int(max_steps))

    def run(self, *, context: CopilotContext, user_message: str) -> CopilotRunResult:
        steps: list[CopilotRunStep] = []
        tool_results: list[AgentToolResult] = []
        cleaned_message = " ".join(str(user_message).strip().split())
        if not cleaned_message:
            raise ValueError("user_message is required")

        for index in range(1, self.max_steps + 1):
            decision_prompt = build_decision_prompt(
                context=context,
                user_message=cleaned_message,
                tools=(tool.schema for tool in self.registry.list_tools()),
                previous_results=tool_results,
            )
            decision = self._parse_decision(self._complete_text(decision_prompt))
            thought = self._optional_text(decision.get("thought"))
            action = self._optional_text(decision.get("action")) or "final"

            if action == "final":
                final_answer = self._optional_text(decision.get("final_answer"))
                if not final_answer:
                    final_answer = self._complete_text(
                        build_final_answer_prompt(
                            context=context,
                            user_message=cleaned_message,
                            tool_results=tool_results,
                        )
                    )
                steps.append(CopilotRunStep(index=index, thought=thought, final_answer=final_answer))
                return CopilotRunResult(
                    answer=final_answer,
                    steps=tuple(steps),
                    metadata={"step_count": len(steps), "tool_result_count": len(tool_results)},
                )

            if action != "tool":
                raise ValueError(f"unsupported agent action: {action}")

            tool_name = self._required_text(decision.get("tool_name"), "tool_name")
            arguments = decision.get("arguments")
            if not isinstance(arguments, Mapping):
                arguments = {}
            tool_call = AgentToolCall(name=tool_name, arguments=dict(arguments), reasoning=thought)
            tool_result = self.executor.execute(context, tool_call)
            tool_results.append(tool_result)
            steps.append(CopilotRunStep(index=index, thought=thought, tool_call=tool_call, tool_result=tool_result))

        final_answer = self._complete_text(
            build_final_answer_prompt(
                context=context,
                user_message=cleaned_message,
                tool_results=tool_results,
            )
        )
        steps.append(CopilotRunStep(index=len(steps) + 1, final_answer=final_answer))
        return CopilotRunResult(
            answer=final_answer,
            steps=tuple(steps),
            metadata={"step_count": len(steps), "tool_result_count": len(tool_results), "stopped_by": "max_steps"},
        )

    def _complete_text(self, prompt: str) -> str:
        response = self.llm.complete(prompt)
        text = getattr(response, "text", None)
        if text is None:
            text = str(response)
        normalized = str(text).strip()
        if not normalized:
            raise ValueError("agent llm returned an empty response")
        return normalized

    @staticmethod
    def _parse_decision(text: str) -> Mapping[str, Any]:
        stripped = text.strip()
        candidates = [stripped]
        if stripped.startswith("```"):
            lines = stripped.splitlines()
            if len(lines) >= 3:
                candidates.append("\n".join(lines[1:-1]).strip())
        start = stripped.find("{")
        end = stripped.rfind("}")
        if start != -1 and end != -1 and end > start:
            candidates.append(stripped[start:end + 1])
        for candidate in candidates:
            if not candidate:
                continue
            try:
                payload = json.loads(candidate)
            except json.JSONDecodeError:
                continue
            if isinstance(payload, Mapping):
                return payload
        raise ValueError("agent decision response must be valid JSON")

    @staticmethod
    def _optional_text(value: Any) -> str | None:
        if value is None:
            return None
        text = " ".join(str(value).strip().split())
        return text or None

    @classmethod
    def _required_text(cls, value: Any, field_name: str) -> str:
        text = cls._optional_text(value)
        if not text:
            raise ValueError(f"{field_name} is required")
        return text
