from __future__ import annotations

from .types import CopilotToolSchema


GET_LESSON_NOTE_TOOL = CopilotToolSchema(
    name="get_lesson_note",
    description="Get the latest generated note for the current lesson.",
    input_schema={},
)

GENERATE_LESSON_NOTE_TOOL = CopilotToolSchema(
    name="generate_lesson_note",
    description="Generate or refresh the lesson note for the current lesson.",
    input_schema={
        "focus": {"type": "string", "required": False},
        "force": {"type": "boolean", "required": False},
        "max_items": {"type": "integer", "required": False},
    },
)

GET_LESSON_TRANSCRIPTS_TOOL = CopilotToolSchema(
    name="get_lesson_transcripts",
    description="Get transcript snippets or counts for the current lesson.",
    input_schema={
        "limit": {"type": "integer", "required": False},
        "source_type": {"type": "string", "required": False},
    },
)

GET_LESSON_VIDEOS_TOOL = CopilotToolSchema(
    name="get_lesson_videos",
    description="Get lesson video metadata and subtitle availability.",
    input_schema={},
)

GET_LESSON_ASSETS_TOOL = CopilotToolSchema(
    name="get_lesson_assets",
    description="Get parsed lesson assets such as PDF or PPT materials.",
    input_schema={},
)

GENERATE_LESSON_QUIZ_TOOL = CopilotToolSchema(
    name="generate_lesson_quiz",
    description="Generate a quiz for the current lesson.",
    input_schema={
        "focus": {"type": "string", "required": False},
        "question_count": {"type": "integer", "required": False},
    },
)

QUERY_LESSON_KNOWLEDGE_TOOL = CopilotToolSchema(
    name="query_lesson_knowledge",
    description="Query the lesson knowledge base for a focused question.",
    input_schema={
        "question": {"type": "string", "required": True},
        "top_k": {"type": "integer", "required": False},
    },
)
