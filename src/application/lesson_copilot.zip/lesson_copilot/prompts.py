from __future__ import annotations

import json
from typing import Iterable, Mapping

from .types import AgentToolResult, CopilotContext, CopilotToolSchema


LESSON_COPILOT_SYSTEM_PROMPT = """You are the Lesson Copilot for a study platform.

Your job is to help the learner review one lesson at a time.
You may inspect lesson notes, transcripts, videos, assets, quizzes, and retrieval results by calling tools.

Rules:
- Stay within the selected lesson context unless the user explicitly asks otherwise.
- Prefer existing generated artifacts before generating new ones again.
- Call at most one tool per step.
- If a tool fails, adapt and either try another tool or explain the limitation.
- When you have enough information, stop calling tools and produce the final answer.
- Return valid JSON only. Do not wrap it in markdown fences.
"""


def build_decision_prompt(
    *,
    context: CopilotContext,
    user_message: str,
    tools: Iterable[CopilotToolSchema],
    previous_results: Iterable[AgentToolResult] = (),
) -> str:
    tool_payload = [
        {
            "name": tool.name,
            "description": tool.description,
            "input_schema": dict(tool.input_schema),
        }
        for tool in tools
    ]
    result_payload = [
        {
            "name": result.name,
            "ok": result.ok,
            "content": result.content,
            "error": result.error,
        }
        for result in previous_results
    ]
    response_schema = {
        "thought": "short reasoning string",
        "action": "tool" ,
        "tool_name": "tool name when action=tool",
        "arguments": {"tool": "arguments"},
        "final_answer": "filled only when action=final",
    }
    return "\n\n".join(
        [
            LESSON_COPILOT_SYSTEM_PROMPT.strip(),
            "Lesson context:",
            json.dumps(_context_to_payload(context), ensure_ascii=False, indent=2),
            "Available tools:",
            json.dumps(tool_payload, ensure_ascii=False, indent=2),
            "Previous tool results:",
            json.dumps(result_payload, ensure_ascii=False, indent=2) if result_payload else "[]",
            f"User request: {user_message.strip()}",
            "Response schema:",
            json.dumps(response_schema, ensure_ascii=False, indent=2),
            "Use action=\"tool\" when you need one more tool call, or action=\"final\" when you can answer now.",
        ]
    )


def build_final_answer_prompt(
    *,
    context: CopilotContext,
    user_message: str,
    tool_results: Iterable[AgentToolResult],
) -> str:
    result_payload = [
        {
            "name": result.name,
            "ok": result.ok,
            "content": result.content,
            "error": result.error,
        }
        for result in tool_results
    ]
    return "\n\n".join(
        [
            "You are the Lesson Copilot final responder.",
            "Write a concise, practical answer for the learner based only on the tool results below.",
            "Do not mention internal tool mechanics unless they failed and that matters.",
            "Lesson context:",
            json.dumps(_context_to_payload(context), ensure_ascii=False, indent=2),
            f"User request: {user_message.strip()}",
            "Tool results:",
            json.dumps(result_payload, ensure_ascii=False, indent=2),
            "Write the final answer only.",
        ]
    )


def _context_to_payload(context: CopilotContext) -> Mapping[str, str | None]:
    return {
        "course_id": context.course_id,
        "lesson_id": context.lesson_id,
        "session_id": context.session_id,
        "subject": context.subject,
        "user_id": context.user_id,
    }
